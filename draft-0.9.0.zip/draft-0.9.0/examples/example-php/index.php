<?php

print "Hello World, I'm a PHP app!\n";
print "This was deployed using Draft!";

?>
