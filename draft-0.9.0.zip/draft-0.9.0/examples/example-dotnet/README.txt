This sample has been generated with the following .NET Core SDK command:

dotnet new web -n WebApplication -o .
