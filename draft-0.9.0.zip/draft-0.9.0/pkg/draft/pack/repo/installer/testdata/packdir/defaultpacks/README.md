# defaultpacks

Default packs for installer integration tests.
