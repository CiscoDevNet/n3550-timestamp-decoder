package pack

import "errors"

var NotFound = errors.New("Could not find a pack Q_Q")
